/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lição.pkg25.pkg04;

import javax.swing.JOptionPane;

/**
 *
 * @author matheus.cpires
 */
public class Lição2504 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String cpf= JOptionPane.showInputDialog(null,"Digite o cpf");
        //String nome= JOptionPane.showInputDialog(null,"Digite seu nome");
        //JOptionPane.showMessageDialog(null,"Seu cpf e"+ cpf + "seu nome" + nome);
        
        
        //for (int i = 1; i < 8; i++) {
          //  JOptionPane.showMessageDialog(null,"repita");
            
            
     //   }
            
        //}
        
    int opcao = JOptionPane.showConfirmDialog(null,"esta chovendo");
        if (opcao == 0) {JOptionPane.showConfirmDialog(null,"Esta Chovendo mundo");
            
        }
        else if (opcao == 1){JOptionPane.showConfirmDialog(null,"ja parou");
            
        }
        else if (opcao == 2){JOptionPane.showConfirmDialog(null,"cancelado");
            
        }
        else{JOptionPane.showConfirmDialog(null,"fechadinho lindão");
            
        }
    }
    
}
