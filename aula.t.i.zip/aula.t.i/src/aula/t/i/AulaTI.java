/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.t.i;

/**
 *
 * @author matheus.cpires
 */
public class AulaTI {
public static void frase(){
    System.out.println("matheus crema");
}
public static void elogio(){
    System.out.println("LINDO");
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frase();
        elogio();
    }
    
}
