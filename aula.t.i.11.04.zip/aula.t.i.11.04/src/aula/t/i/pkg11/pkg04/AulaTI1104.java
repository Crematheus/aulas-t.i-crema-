/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.t.i.pkg11.pkg04;

import javax.swing.JOptionPane;

/**
 *
 * @author matheus.cpires
 */
public class AulaTI1104 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //JOptionPane.showMessageDialog(null,"oiiii");
        JOptionPane.showMessageDialog(null,"mensagem do Crema");
        JOptionPane.showInputDialog(null,"qual sua idade?");
        JOptionPane.showConfirmDialog(null," vamos fodeeer ? ");
    }
    
}
